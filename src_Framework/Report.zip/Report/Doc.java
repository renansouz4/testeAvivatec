package Report;


import java.io.FileInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import com.aspose.words.Document;
import com.aspose.words.DocumentBuilder;
import com.aspose.words.FormField;
import com.aspose.words.License;
import com.aspose.words.TextFormFieldType;
import com.aspose.words.WrapType;
import com.itextpdf.text.PageSize;

import ConstantsFramework.Constants_Framework;

//import managers.FileReaderManager;

public class Doc{

	public Doc(ArrayList<?> array,ArrayList<?> arrayText) throws Exception {
		int verticalPosition = 0;
		String dataPath = Constants_Framework.DOC_PATH;
		DateFormat dateFormat = new SimpleDateFormat("yy-MM-dd HH-mm-ss");
		Date date = new Date();
		Document doc = new Document(dataPath);
		DocumentBuilder builder = new DocumentBuilder(doc);

		// Instancia e define Aspose.Pdf License <o: p> </ o: p>

		//License license = new License ();
	//	FileInputStream fstream = new FileInputStream (( "Aspose.Total.lic" ));
		//license.setLicense (fstream);

		// Instancia e define Aspose.Imaging License
		//License licenseimg = new License ();
		//FileInputStream fstreamimg = new FileInputStream (( "Aspose.Words.lic" ));
		//license.setLicense (fstreamimg);
		

//com.aspose.words.License license = new com.aspose.words.License();
//license.setLicense("Aspose.Words.Java.lic");
		
		for (int i = 0; i < array.size(); i++) {
			String imagePath = (String) array.get(i);
			String text = (String) arrayText.get(i);
			//builder.insertImage(imagePath, -1000, -40, 0, verticalPosition, 500, 300, WrapType.SQUARE);
			//FileInputStream in1 = new FileInputStream("\n");
			FileInputStream in = new FileInputStream(imagePath);
		//	builder.insertImage(in1);
			//builder.insertParagraph();
			//builder.write ( "" );
			 builder.insertTextInput( "" , 1,"", "\n"+text,0).getTextInputDefault();
		
	
			builder.insertImage(in,480,270);

			verticalPosition = verticalPosition + 400;
		}
		doc.save(dataPath + dateFormat.format(date) + ".docx");
	}
}
